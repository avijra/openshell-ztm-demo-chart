{{/*
Auto-detect the OpenShift cluster domain from the Ingress config.
*/}}
{{- define "ztm.clusterDomain" -}}
{{- $ing := (lookup "config.openshift.io/v1" "Ingress" "" "cluster") -}}
{{- if and $ing $ing.spec $ing.spec.domain -}}
{{- $ing.spec.domain -}}
{{- else -}}
apps.rosa.rosa-wjw4q.8pwg.p3.openshiftapps.com
{{- end -}}
{{- end -}}

{{/*
Default OpenShift Route hostname for OpenShell gateway.
*/}}
{{- define "ztm.routeHostname" -}}
{{- if .Values.openshell.openshiftRoute.host -}}
{{- .Values.openshell.openshiftRoute.host -}}
{{- else -}}
openshell.{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
Keycloak base URL derived from cluster domain.
*/}}
{{- define "ztm.keycloakUrl" -}}
{{- if .Values.keycloak.baseUrl -}}
{{- .Values.keycloak.baseUrl -}}
{{- else -}}
https://keycloak.{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
SPIFFE trust domain derived from cluster domain.
*/}}
{{- define "ztm.trustDomain" -}}
{{- if .Values.spiffe.trustDomain -}}
{{- .Values.spiffe.trustDomain -}}
{{- else -}}
{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
Standard labels for ZTM resources.
*/}}
{{- define "ztm.labels" -}}
app.kubernetes.io/name: openshell-ztm-demo
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}
