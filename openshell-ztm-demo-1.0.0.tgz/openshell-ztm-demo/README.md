# OpenShell ZTM Demo

Deploy the OpenShell secure AI agent runtime integrated with the ZTVP (Zero Trust
Validated Pattern) stack on OpenShift.

## What Gets Deployed

- **OpenShell Gateway** -- control plane for agent sandboxes, policy, and access
- **OpenShell Supervisor** -- manages sandbox lifecycle
- **Pi Agent Sandbox** -- pre-configured AI agent (Pi from pi.dev) with zero-trust policy
- **SPIFFE Identity** -- workload identity via ZTWIM (ClusterSPIFFEID)
- **Vault Integration** -- DeepSeek API key stored in HashiCorp Vault, synced via ESO
- **Keycloak SSO** -- OIDC client registration for operator authentication
- **ACS Scanning** -- sandbox image built on-cluster and scanned by StackRox
- **Network Policies** -- default deny with selective allow for gateway traffic

## Prerequisites

This chart requires a running ZTVP (Layered Zero Trust Validated Pattern) deployment
with the following components healthy in ArgoCD:

- HashiCorp Vault (namespace: vault)
- External Secrets Operator (namespace: external-secrets)
- Red Hat Build of Keycloak (namespace: keycloak-system)
- Zero Trust Workload Identity Manager / SPIRE (namespace: zero-trust-workload-identity-manager)
- Red Hat Advanced Cluster Security (namespace: stackrox)

## Install from Web Console

1. Navigate to **Developer Catalog > Helm Charts**
2. Find **OpenShell ZTM Demo**
3. Click **Create**
4. Enter your **DeepSeek API Key** in the Form View
5. Click **Install**

## Install from CLI

```shell
helm install openshell-demo openshell-ztm-demo/ \
  --namespace openshell-system \
  --create-namespace \
  --set deepseek.apiKey=<YOUR_KEY> \
  --set global.clusterDomain=apps.rosa-wjw4q.8pwg.p3.openshiftapps.com
```

## Uninstall

From the web console: **Helm Releases > openshell-demo > Actions > Delete**

From the CLI:

```shell
helm uninstall openshell-demo -n openshell-system
```

The pre-delete hook destroys all sandboxes before removing resources.

## Configuration

| Parameter | Description | Default |
|---|---|---|
| `global.clusterDomain` | Cluster apps domain (auto-detected) | `""` |
| `deepseek.apiKey` | DeepSeek API key | `""` |
| `deepseek.endpoint` | DeepSeek API URL | `https://api.deepseek.com` |
| `gateway.replicas` | Gateway replicas | `1` |
| `vault.enabled` | Enable Vault integration | `true` |
| `keycloak.enabled` | Enable Keycloak SSO | `true` |
| `spiffe.enabled` | Enable SPIFFE identity | `true` |
| `pi.sandbox.name` | Sandbox name | `pi-agent-demo` |
| `pi.buildFromSource` | Build Pi image on-cluster | `true` |
| `route.enabled` | Expose gateway via Route | `true` |
