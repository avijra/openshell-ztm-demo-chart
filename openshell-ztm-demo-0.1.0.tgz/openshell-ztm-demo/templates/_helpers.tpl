{{/*
Chart name
*/}}
{{- define "openshell-ztm-demo.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name
*/}}
{{- define "openshell-ztm-demo.fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "openshell-ztm-demo.labels" -}}
helm.sh/chart: {{ include "openshell-ztm-demo.name" . }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "openshell-ztm-demo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: zero-trust-mesh
{{- end }}

{{/*
Selector labels
*/}}
{{- define "openshell-ztm-demo.selectorLabels" -}}
app.kubernetes.io/name: {{ include "openshell-ztm-demo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Resolve cluster domain -- use provided value or fall back to
the cluster's apps domain detected via lookup.
*/}}
{{- define "openshell-ztm-demo.clusterDomain" -}}
{{- if .Values.global.clusterDomain }}
{{- .Values.global.clusterDomain }}
{{- else }}
{{- $ingress := (lookup "config.openshift.io/v1" "Ingress" "" "cluster") }}
{{- if $ingress }}
{{- $ingress.spec.domain }}
{{- else }}
{{- "apps.example.com" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Gateway route hostname
*/}}
{{- define "openshell-ztm-demo.routeHostname" -}}
{{- if .Values.route.hostname }}
{{- .Values.route.hostname }}
{{- else }}
{{- printf "openshell.%s" (include "openshell-ztm-demo.clusterDomain" .) }}
{{- end }}
{{- end }}

{{/*
Keycloak base URL
*/}}
{{- define "openshell-ztm-demo.keycloakUrl" -}}
{{- if .Values.keycloak.baseUrl }}
{{- .Values.keycloak.baseUrl }}
{{- else }}
{{- printf "https://keycloak.%s" (include "openshell-ztm-demo.clusterDomain" .) }}
{{- end }}
{{- end }}

{{/*
SPIFFE trust domain
*/}}
{{- define "openshell-ztm-demo.trustDomain" -}}
{{- if .Values.spiffe.trustDomain }}
{{- .Values.spiffe.trustDomain }}
{{- else }}
{{- include "openshell-ztm-demo.clusterDomain" . }}
{{- end }}
{{- end }}

{{/*
Namespace
*/}}
{{- define "openshell-ztm-demo.namespace" -}}
{{- .Values.namespace }}
{{- end }}
