{{/*
Auto-detect the OpenShift cluster domain from the Ingress config.
Falls back to global.clusterDomain if set, otherwise errors at template time.
*/}}
{{- define "ztm.clusterDomain" -}}
{{- if .Values.global.clusterDomain -}}
{{- .Values.global.clusterDomain -}}
{{- else -}}
{{- $ing := (lookup "config.openshift.io/v1" "Ingress" "" "cluster") -}}
{{- if and $ing $ing.spec $ing.spec.domain -}}
{{- $ing.spec.domain -}}
{{- else -}}
{{- fail "Cannot auto-detect cluster domain. Set global.clusterDomain in values.yaml" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Default OpenShift Route hostname for OpenShell gateway.
*/}}
{{- define "ztm.routeHostname" -}}
{{- if .Values.openshell.openshiftRoute.host -}}
{{- .Values.openshell.openshiftRoute.host -}}
{{- else -}}
openshell.{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
Keycloak base URL derived from cluster domain.
*/}}
{{- define "ztm.keycloakUrl" -}}
{{- if .Values.keycloak.baseUrl -}}
{{- .Values.keycloak.baseUrl -}}
{{- else -}}
https://keycloak.{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
SPIFFE trust domain derived from cluster domain.
*/}}
{{- define "ztm.trustDomain" -}}
{{- if .Values.spiffe.trustDomain -}}
{{- .Values.spiffe.trustDomain -}}
{{- else -}}
{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
Vault internal (in-cluster) URL. Standard ZTVP location.
*/}}
{{- define "ztm.vaultInternalUrl" -}}
{{- if .Values.vault.internalUrl -}}
{{- .Values.vault.internalUrl -}}
{{- else -}}
https://vault.{{ .Values.vault.namespace }}.svc.cluster.local:8200
{{- end -}}
{{- end -}}

{{/*
Vault external URL derived from cluster domain.
*/}}
{{- define "ztm.vaultExternalUrl" -}}
{{- if .Values.vault.url -}}
{{- .Values.vault.url -}}
{{- else -}}
https://vault-vault.{{ include "ztm.clusterDomain" . }}
{{- end -}}
{{- end -}}

{{/*
Gateway in-cluster service name — mirrors the subchart's openshell.fullname logic:
  if release name contains nameOverride → just release name
  else → release-nameOverride
*/}}
{{- define "ztm.gatewayServiceName" -}}
{{- $name := .Values.openshell.nameOverride | default "openshell" -}}
{{- if contains $name .Release.Name -}}
{{ .Release.Name }}
{{- else -}}
{{ .Release.Name }}-{{ $name }}
{{- end -}}
{{- end -}}

{{/*
Gateway in-cluster gRPC endpoint (used by openshell CLI in hook jobs).
Port 8080 is the gateway gRPC/HTTP port exposed by the Service.
*/}}
{{- define "ztm.gatewayEndpoint" -}}
https://{{ include "ztm.gatewayServiceName" . }}.{{ .Values.namespace }}.svc.cluster.local:8080
{{- end -}}

{{/*
Standard labels for ZTM resources.
*/}}
{{- define "ztm.labels" -}}
app.kubernetes.io/name: openshell-ztm-demo
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end -}}
