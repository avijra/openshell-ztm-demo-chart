# OpenShell ZTM Demo

Deploy the OpenShell secure AI agent runtime integrated with the ZTVP (Zero Trust
Validated Pattern) stack on OpenShift.

## What Gets Deployed

- **OpenShell Gateway** — control plane for agent sandboxes, policy, and access
- **OpenShell Supervisor** — manages sandbox lifecycle
- **Pi Agent Sandbox** — pre-configured AI agent (Pi from pi.dev) with zero-trust policy
- **SPIFFE Identity** — workload identity via ZTWIM (ClusterSPIFFEID)
- **Vault Integration** — DeepSeek API key stored in HashiCorp Vault, synced via ESO
- **Keycloak SSO** — OIDC client registration for operator authentication
- **ACS Scanning** — sandbox image built on-cluster and scanned by StackRox
- **Network Policies** — default deny with selective allow for gateway traffic

## Prerequisites

This chart requires a running ZTVP (Layered Zero Trust Validated Pattern) deployment
with the following components healthy in ArgoCD:

- HashiCorp Vault (namespace: `vault`)
- External Secrets Operator (namespace: `external-secrets`)
- Red Hat Build of Keycloak (namespace: `keycloak-system`)
- Zero Trust Workload Identity Manager / SPIRE (namespace: `zero-trust-workload-identity-manager`)
- Red Hat Advanced Cluster Security (namespace: `stackrox`)
- Compliance Operator

## Install from Web Console

1. Navigate to **Developer Catalog → Helm Charts**
2. Find **OpenShell ZTM Demo**
3. Click **Create**
4. Enter your **DeepSeek API Key** in the Form View
5. Click **Install**

## Install from CLI

```shell
helm install openshell-demo openshell-ztm-demo/openshell-ztm-demo \
  --namespace openshell-system \
  --create-namespace \
  --set deepseek.apiKey=<YOUR_DEEPSEEK_KEY>
```

The chart auto-detects the cluster domain from the OpenShift Ingress config.
Override only if detection fails (e.g. disconnected environments):

```shell
--set global.clusterDomain=apps.mycluster.example.com
```

## Uninstall

From the web console: **Helm Releases → openshell-demo → Actions → Delete**

From the CLI:

```shell
helm uninstall openshell-demo -n openshell-system
```

The pre-delete hook destroys all sandboxes and cancels builds before removing resources.

To also remove the namespace (optional):

```shell
oc delete namespace openshell-system
```

## Reinstall

After uninstall, wait a few seconds for cleanup, then install again:

```shell
helm install openshell-demo openshell-ztm-demo/openshell-ztm-demo \
  --namespace openshell-system \
  --create-namespace \
  --set deepseek.apiKey=<YOUR_DEEPSEEK_KEY>
```

## Configuration

| Parameter | Description | Default |
|---|---|---|
| `global.clusterDomain` | Cluster apps domain (auto-detected from OpenShift) | `""` |
| `deepseek.apiKey` | **REQUIRED** — DeepSeek API key | `""` |
| `deepseek.endpoint` | DeepSeek API URL | `https://api.deepseek.com` |
| `vault.enabled` | Enable Vault integration | `true` |
| `vault.namespace` | Namespace where Vault runs | `vault` |
| `vault.internalUrl` | Vault in-cluster URL | `https://vault.vault.svc.cluster.local:8200` |
| `vault.role` | Vault Kubernetes auth role | `openshell-admin` |
| `vault.clusterSecretStoreName` | ESO ClusterSecretStore name | `vault-backend` |
| `keycloak.enabled` | Enable Keycloak SSO | `true` |
| `keycloak.namespace` | Keycloak Operator namespace | `keycloak-system` |
| `keycloak.realm` | Keycloak realm | `ztvp` |
| `spiffe.enabled` | Enable SPIFFE identity | `true` |
| `spiffe.clusterName` | ZTVP cluster name | `""` |
| `pi.sandbox.name` | Sandbox name | `pi-agent-demo` |
| `agentSandboxCRD.install` | Auto-install Agent Sandbox CRD | `true` |
| `openshell.openshiftRoute.enabled` | Expose gateway via Route | `true` |
